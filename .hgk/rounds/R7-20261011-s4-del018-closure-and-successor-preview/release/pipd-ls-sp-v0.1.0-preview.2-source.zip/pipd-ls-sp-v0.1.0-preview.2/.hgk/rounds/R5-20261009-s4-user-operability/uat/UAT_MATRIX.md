# R5 S4 UAT matrix — 2026-10-10T04:55:11Z

wheel: `dist\pipd_ls_sp-0.1.0-py3-none-any.whl` sha256 `e49d38e519117d67de57153658779eafa139eb0dda5a6d15f486facb44fd00e2`

| case | mode | verdict | actual |
|---|---|---|---|
| UAT-00 | source | PASS | exit=0 families19='families' |
| UAT-01 | source | PASS | intake=0 pi=0 atoms=4 negative=2 |
| UAT-02 | source | PASS | exits=[0, 0, 0] bad=2 profile_meta_differs=True canon_hash={'LITE': '316989a031b9', 'STANDARD': '6c0feb7381ea', 'ASSURED': 'd2f8ff5dc0bc'} |
| UAT-03 | source | PASS | pd=0 ecp=0 tqaep=2 host_derived=True |
| UAT-04 | source | PASS | good=0 tampered=1 missing=2 |
| UAT-05 | source | PASS | dry=0 writes=False canary_same=True dot=2 msys=2 |
| UAT-06 | source | PASS | project=0 web=5 host=3 ir=True negative_leaks=[] canary_ok=True src_stable=True |
| UAT-07 | source | PASS | dry=0 dry_clean=True export=0 files=3 recompute=True [rows=72 members=72 bad=[] archive_sha_recomputed=True sha256sums=True] |
| UAT-08 | source | PASS | diff=0 missing=2 repair=0 escape=2 noscope=2 |
| UAT-09 | source | PASS | exit=[0, 0] hashes_equal=True h0=adae317353022b8a |
| UAT-10 | source | INFO | skipped in source mode |
| UAT-11 | source | PASS | small_atoms=2 large_atoms=801 s2_check_exit=0 s2_preserved_fail_visible=True s2_voting=['bytes_per_atom'] s2_bytes_per_atom=1449.6 |
| UAT-12 | source | PASS | export=2 exp_exists=False leaked=False foreign=2 root=2 intake_inj=0 |
| UAT-ENV | install | INFO | wheel installed; offline-provisioned dependency packages: ['attr', 'attrs', 'jsonschema', 'jsonschema_specifications', 'referencing', 'rpds', 'typing_extensions.py'] |
| UAT-00 | install | PASS | venv=0 pip=0 probe=0 out_of_repo=True out={"mod": "C:\\Users\\user\\AppData\\Local\\Packages\\OpenAI.Codex_2p2nqsd0c76g0\\LocalCache\\Local\\hermes\\cache\\scratch\\r5-uat\\uat00_venv\\venv\\Lib\\site-packages\\pipd_ls_s |
| UAT-01 | install | PASS | intake=0 pi=0 atoms=4 negative=2 |
| UAT-02 | install | PASS | exits=[0, 0, 0] bad=2 profile_meta_differs=True canon_hash={'LITE': '316989a031b9', 'STANDARD': '6c0feb7381ea', 'ASSURED': 'd2f8ff5dc0bc'} |
| UAT-03 | install | PASS | pd=0 ecp=0 tqaep=2 host_derived=True |
| UAT-04 | install | PASS | good=0 tampered=1 missing=2 |
| UAT-05 | install | PASS | dry=0 writes=False canary_same=True dot=2 msys=2 |
| UAT-06 | install | PASS | project=0 web=5 host=3 ir=True negative_leaks=[] canary_ok=True src_stable=True |
| UAT-07 | install | PASS | dry=0 dry_clean=True export=0 files=3 recompute=True [rows=72 members=72 bad=[] archive_sha_recomputed=True sha256sums=True] |
| UAT-08 | install | PASS | diff=0 missing=2 repair=0 escape=2 noscope=2 |
| UAT-09 | install | PASS | exit=[0, 0] hashes_equal=True h0=adae317353022b8a |
| UAT-10 | install | PASS | steps=[0, 0, 0, 0, 0, 0] residue=[] reg=19 |
| UAT-11 | install | PASS | small_atoms=2 large_atoms=801 s2_check_exit=0 s2_preserved_fail_visible=True s2_voting=['bytes_per_atom'] s2_bytes_per_atom=1449.6 |
| UAT-12 | install | PASS | export=2 exp_exists=False leaked=False foreign=2 root=2 intake_inj=0 |
