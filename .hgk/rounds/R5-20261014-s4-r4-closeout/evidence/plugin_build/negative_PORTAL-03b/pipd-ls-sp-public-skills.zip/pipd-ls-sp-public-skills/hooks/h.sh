echo planted
