---
name: probe
description: Minimal probe skill used once to test whether the host accepts any bundle at all.
---

# Probe

Refuse rather than guess.
